LED=/karotz/bin/led

function SAY {
    killall madplay
    LD_LIBRARY_PATH=/tmp /tmp/madplay /tmp/$1.mp3 $2
}

function EARSMOVE {
    killall ears
    /tmp/ears &
}


BLACK="000000"
BLUE="0000FF"
CYAN="00FF9F"
GREEN="00FF00"
ORANGE="FFA500"
PINK="FFCFAF"
PURPLE="9F00FF"
RED="FF0000"
YELLOW="75FF00"
WHITE="4FFF68"

function LEDRED {
killall led
$LED -l $RED -p 000000 -d 1500 &
}

function LEDGREEN {
killall led
$LED -l $GREEN -p 000000 -d 1500 &
}

function LEDCYAN {
killall led
$LED -l $CYAN -p 000000 -d 1500 &
}

function LEDORANGE {
killall led
$LED -l $ORANGE -p 000000 -d 1500 &
}

function LEDORANGEFIX {
killall led
$LED -l $ORANGE

}

function LEDGREENFIX {
killall led
$LED -l $GREEN

}

function LEDWHITE {
killall led
$LED -l $WHITE 
}

function ledColor {
killall led
$LED -l  "FFFF00"

}

SAY "blank" 
SAY "SFX_bonjour" 
EARSMOVE
SAY "3"
SAY "SFX_Inter"
SAY "5"
SAY "SFX_Inter"
SAY "7"
SAY "SFX_Inter"
SAY "9"
SAY "SFX_Inter"
SAY "11"
SAY "SFX_ICanDo"
SAY "13"
SAY "SFX_Musicfade"
SAY "SFX_Inter"
EARSMOVE
SAY "15"
LEDCOLOR
SAY "16"

LEDRED
SAY "17"
SAY "SFX_Red_Led"

LEDGREEN
SAY "19"
SAY "SFX_Green_Led"

LEDCYAN
SAY "21"
SAY "SFX_Cyan_Led"

LEDORANGE
SAY "23"
SAY "SFX_Orange_Led"

LEDWHITE
SAY "25"
SAY "SFX_White_Led"

LEDORANGEFIX
SAY "28"
LEDGREEN
SAY "SFX_Inter"
LEDWHITE
SAY "30"
SAY "SFX_Inter"
SAY "32"
SAY "SFX_Photo"
SAY "38"
SAY "SFX_Camera"
SAY "40"
SAY "SFX_Fin"
LEDGREEN

